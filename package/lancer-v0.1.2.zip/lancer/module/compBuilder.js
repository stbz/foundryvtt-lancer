import { PilotEquipType, ItemType } from "./enums.js";
import data from 'lancer-data';
export const convertLancerData = async function () {
    // await buildSkillCompendium();
    // await buildTalentCompendium();
    // await buildCoreBonusCompendium();
    // await buildPilotEquipmentCompendiums();
    await buildFrameCompendium();
    await buildMechSystemCompendium();
    await buildMechWeaponCompendium();
    return Promise.resolve();
};
async function findPack(pack_name, metaData) {
    let pack;
    // Find existing system compendium
    pack = game.packs.get(`lancer.${pack_name}`);
    if (!pack) {
        // System compendium doesn't exist, attempt to find a world compendium
        pack = game.packs.get(`world.${pack_name}`);
    }
    if (pack) {
        console.log(`LANCER | Updating existing compendium: ${pack.collection}.`);
        pack.locked = false;
    }
    else {
        // Compendium doesn't exist yet. Create a new one.
        pack = await Compendium.create(metaData);
        console.log(`LANCER | Building new compendium: ${pack.collection}.`);
    }
    return pack;
}
async function updateItem(pack, newData, type, img) {
    let entry = pack.index.find(e => e.name === newData.name);
    // The item already exists in the pack, update its data.
    if (entry) {
        console.log(`LANCER | Updating ${type} ${entry.name} in compendium ${pack.collection}`);
        let e = (await pack.getEntity(entry._id));
        console.log("Old:");
        console.log(e);
        let d = e.data;
        d.data = newData;
        d.img = img;
        let f = await pack.updateEntity(d, { entity: e });
        console.log("New:");
        console.log(f);
        return f;
    }
    else {
        // The item doesn't exist yet, create it
        const itemData = {
            name: newData.name,
            img: img,
            type: type,
            flags: {},
            data: newData
        };
        console.log(`LANCER | Adding ${type} ${itemData.name} to compendium ${pack.collection}`);
        // Create an Item from the item data
        return await pack.createEntity(itemData);
    }
}
async function buildSkillCompendium() {
    const skills = data.skills;
    const img = "systems/lancer/assets/icons/accuracy.svg";
    const metaData = {
        name: "skills",
        label: "Skill Triggers",
        system: "lancer",
        package: "lancer",
        path: "./packs/skills.db",
        entity: "Item"
    };
    let pack = await findPack("skills", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of skills and add them each to the Compendium
    skills.forEach(async (skill) => {
        updateItem(pack, skill, "skill", img);
    });
    return Promise.resolve();
}
async function buildTalentCompendium() {
    const talents = data.talents;
    const img = "systems/lancer/assets/icons/chevron_3.svg";
    const metaData = {
        name: "talents",
        label: "Talents",
        system: "lancer",
        package: "lancer",
        path: "./packs/talents.db",
        entity: "Item"
    };
    let pack = await findPack("talents", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of talents and add them each to the Compendium
    talents.forEach(async (talent) => {
        updateItem(pack, talent, "talent", img);
    });
    return Promise.resolve();
}
async function buildCoreBonusCompendium() {
    const coreBonus = data.core_bonuses;
    const img = "systems/lancer/assets/icons/corebonus.svg";
    const metaData = {
        name: "core_bonuses",
        label: "Core Bonuses",
        system: "lancer",
        package: "lancer",
        path: "./packs/core_bonuses.db",
        entity: "Item"
    };
    let pack = await findPack("core_bonuses", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of core bonuses and add them each to the Compendium
    coreBonus.forEach(async (cbonus) => {
        updateItem(pack, cbonus, "core_bonus", img);
    });
    return Promise.resolve();
}
async function buildPilotEquipmentCompendiums() {
    console.log("LANCER | Building Pilot Equipment compendiums.");
    const pilotGear = data.pilot_gear;
    const armImg = "systems/lancer/assets/icons/role_tank.svg";
    const weapImg = "systems/lancer/assets/icons/weapon.svg";
    const gearImg = "systems/lancer/assets/icons/trait.svg";
    const armorMeta = {
        name: "pilot_armor",
        label: "Pilot Armor",
        system: "lancer",
        package: "lancer",
        path: "./packs/pilot_armor.db",
        entity: "Item"
    };
    let paPack = await findPack("pilot_armor", armorMeta);
    const weaponMeta = {
        name: "pilot_weapons",
        label: "Pilot Weapons",
        system: "lancer",
        package: "lancer",
        path: "./packs/pilot_weapons.db",
        entity: "Item"
    };
    let pwPack = await findPack("pilot_weapons", weaponMeta);
    const gearMeta = {
        name: "pilot_gear",
        label: "Pilot Gear",
        system: "lancer",
        package: "lancer",
        path: "./packs/pilot_gear.db",
        entity: "Item"
    };
    let pgPack = await findPack("pilot_gear", gearMeta);
    paPack.locked = false;
    pwPack.locked = false;
    pgPack.locked = false;
    await paPack.getIndex();
    await pwPack.getIndex();
    await pgPack.getIndex();
    // Iterate through the list of talents and add them each to the Compendium
    pilotGear.forEach(async (equip) => {
        if (equip.type === PilotEquipType.PilotArmor) {
            delete equip.type;
            equip.item_type = ItemType.PilotArmor;
            updateItem(paPack, equip, "pilot_armor", armImg);
        }
        else if (equip.type === PilotEquipType.PilotWeapon) {
            delete equip.type;
            equip.item_type = ItemType.PilotWeapon;
            updateItem(pwPack, equip, "pilot_weapon", weapImg);
        }
        else if (equip.type === PilotEquipType.PilotGear) {
            delete equip.type;
            let gear = equip;
            gear.item_type = ItemType.PilotGear;
            if (gear.uses) {
                gear.current_uses = gear.uses;
            }
            updateItem(pgPack, gear, "pilot_gear", gearImg);
        }
        else {
            // Error - unknown type!
            throw TypeError(`Unknown pilot equipment type: ${equip.type}.`);
        }
    });
    return Promise.resolve();
}
async function buildFrameCompendium() {
    const frames = data.frames;
    const img = "systems/lancer/assets/icons/frame.svg";
    const metaData = {
        name: "frames",
        label: "Frames",
        system: "lancer",
        package: "lancer",
        path: "./packs/frames.db",
        entity: "Item"
    };
    let pack = await findPack("frames", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of core bonuses and add them each to the Compendium
    frames.forEach(async (frameRaw) => {
        // Remove Comp/Con-specific data
        delete frameRaw.data_type;
        delete frameRaw.aptitude;
        delete frameRaw.y_pos;
        delete frameRaw.other_art;
        // Re-type and set missing data
        let frame = frameRaw;
        frame.license = frame.name;
        frame.license_level = 2;
        frame.item_type = ItemType.Frame;
        updateItem(pack, frame, "frame", img);
        // TODO: Add license Item to licenses pack
    });
    return Promise.resolve();
}
async function buildMechSystemCompendium() {
    const systems = data.systems;
    const img = "systems/lancer/assets/icons/system.svg";
    const metaData = {
        name: "systems",
        label: "Systems",
        system: "lancer",
        package: "lancer",
        path: "./packs/systems.db",
        entity: "Item"
    };
    let pack = await findPack("systems", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of core bonuses and add them each to the Compendium
    systems.forEach(async (systemRaw) => {
        // Remove Comp/Con specific data
        delete systemRaw.aptitude;
        systemRaw.system_type = systemRaw.type;
        delete systemRaw.type;
        // Re-type and set missing data
        let system = systemRaw;
        system.item_type = ItemType.MechSystem;
        updateItem(pack, system, "mech_system", img);
        // TODO: Add reference in the license Item
    });
    return Promise.resolve();
}
async function buildMechWeaponCompendium() {
    const weapons = data.weapons;
    const img = "systems/lancer/assets/icons/weapon.svg";
    const metaData = {
        name: "weapons",
        label: "Weapons",
        system: "lancer",
        package: "lancer",
        path: "./packs/weapons.db",
        entity: "Item"
    };
    let pack = await findPack("weapons", metaData);
    pack.locked = false;
    await pack.getIndex();
    // Iterate through the list of core bonuses and add them each to the Compendium
    weapons.forEach(async (weapon) => {
        weapon.item_type = ItemType.MechWeapon;
        updateItem(pack, weapon, "mech_weapon", img);
        // TODO: Add reference in the license Item
    });
    return Promise.resolve();
}
