/**
 * Extend the Actor class for Lancer Pilot-type actors.
 */
export class LancerPilot extends Actor {
}
/**
 * Extend the Actor class for Lancer NPC-type actors.
 */
export class LancerNPC extends Actor {
}
/**
 *
 */
export class LancerDeployable extends Actor {
}
