/**
 * Perform a system migration for the entire World, applying migrations for Actors, Items, and Compendium packs
 * @return {Promise}      A Promise which resolves once the migration is completed
 */
export const migrateWorld = async function () {
    ui.notifications.info(`Applying LANCER System Migration for version ${game.system.data.version}. Please be patient and do not close your game or shut down your server.`, { permanent: true });
    // Migrate World Actors
    for (let a of game.actors.entities) {
        try {
            const updateData = migrateActorData(a);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Actor entity ${a.name}`);
                await a.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate World Items
    for (let i of game.items.entities) {
        try {
            const updateData = migrateItemData(i);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Item entity ${i.name}`);
                await i.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate Actor Override Tokens
    for (let s of game.scenes.entities) {
        try {
            const updateData = migrateSceneData(s);
            if (!isObjectEmpty(updateData)) {
                console.log(`Migrating Scene entity ${s.name}`);
                await s.update(updateData, { enforceTypes: false });
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    // Migrate World Compendium Packs
    game.packs.forEach(async (p) => {
        if ((p.metadata.package === "world") && ["Actor", "Item", "Scene"].includes(p.metadata.entity)) {
            await migrateCompendium(p);
        }
    });
    // Set the migration as complete
    game.settings.set("lancer", "systemMigrationVersion", game.system.data.version);
    ui.notifications.info(`LANCER System Migration to version ${game.system.data.version} completed!`, { permanent: true });
};
/* -------------------------------------------- */
/**
 * Apply migration rules to all Entities within a single Compendium pack
 * @param pack
 * @return {Promise}
 */
export const migrateCompendium = async function (pack) {
    const entity = pack.metadata.entity;
    if (!["Actor", "Item", "Scene"].includes(entity))
        return;
    // Begin by requesting server-side data model migration and get the migrated content
    await pack.migrate({});
    const content = await pack.getContent();
    // Iterate over compendium entries - applying fine-tuned migration functions
    for (let ent of content) {
        try {
            let updateData = null;
            if (entity === "Item")
                updateData = migrateItemData(ent);
            else if (entity === "Actor")
                updateData = migrateActorData(ent);
            else if (entity === "Scene")
                updateData = migrateSceneData(ent.data);
            if (!isObjectEmpty(updateData)) {
                expandObject(updateData);
                updateData["_id"] = ent._id;
                await pack.updateEntity(updateData);
                console.log(`Migrated ${entity} entity ${ent.name} in Compendium ${pack.collection}`);
            }
        }
        catch (err) {
            console.error(err);
        }
    }
    console.log(`Migrated all ${entity} entities from Compendium ${pack.collection}`);
};
/* -------------------------------------------- */
/*  Entity Type Migration Helpers               */
/* -------------------------------------------- */
/**
 * Migrate a single Actor entity to incorporate latest data model changes
 * Return an Object of updateData to be applied
 * @param {Actor} actor   The actor to Update
 * @return {Object}       The updateData to apply
 */
export const migrateActorData = function (actor) {
    const updateData = {};
    const ad = actor.data;
    // Migrate to pilot data model
    if (ad.type === "pc" || ad.type === "npc") {
        console.log(ad);
        // Mech data'
        updateData.mech = {};
        updateData.mech.hull = ad.data.mech.hull.value;
        updateData.mech.agility = ad.data.mech.agility.value;
        updateData.mech.systems = ad.data.mech.systems.value;
        updateData.mech.engineering = ad.data.mech.engineering.value;
        updateData.mech.armor = ad.data.mech.armor.value;
        updateData.mech.speed = ad.data.mech.speed.value;
        updateData.mech.evasion = ad.data.mech.evasion.value;
        updateData.mech.edef = ad.data.mech.edef.value;
        updateData.mech.sensors = ad.data.mech.sensors.value;
        updateData.mech.save = ad.data.mech.save.value;
    }
    if (ad.type === "pc") {
        // Pilot data
        updateData.pilot = {};
        updateData.pilot.grit = ad.data.pilot.grit.value;
        updateData.pilot.stats = {};
        updateData.pilot.stats.armor = ad.data.pilot.stats.armor.value;
        updateData.pilot.stats.evasion = ad.data.pilot.stats.evasion.value;
        updateData.pilot.stats.edef = ad.data.pilot.stats.edef.value;
        updateData.pilot.stats.speed = ad.data.pilot.stats.speed.value;
        // Migrate type to pilot
        updateData.type = "pilot";
    }
    // Migrate Owned Items
    if (!actor.items)
        return updateData;
    let hasItemUpdates = false;
    const items = actor.items.map(i => {
        // Migrate the Owned Item
        let itemUpdate = migrateItemData(i);
        // Update the Owned Item
        if (!isObjectEmpty(itemUpdate)) {
            hasItemUpdates = true;
            return mergeObject(i, itemUpdate, { enforceTypes: false, inplace: false });
        }
        else
            return i;
    });
    if (hasItemUpdates)
        updateData.items = items;
    // Remove deprecated fields
    _migrateRemoveDeprecated(actor, updateData);
    return updateData;
};
/* -------------------------------------------- */
/**
 * Scrub an Actor's system data, removing all keys which are not explicitly defined in the system template
 * @param {ActorData} actorData    The data object for an Actor
 * @return {ActorData}             The scrubbed Actor data
 */
function cleanActorData(actorData) {
    // Scrub system data
    const model = game.system.model.Actor[actorData.type];
    actorData.data = filterObject(actorData.data, model);
    // Scrub system flags
    const allowedFlags = CONFIG.LANCER.allowedActorFlags.reduce((obj, f) => {
        obj[f] = null;
        return obj;
    }, {});
    if (actorData.flags.dnd5e) {
        actorData.flags.dnd5e = filterObject(actorData.flags.dnd5e, allowedFlags);
    }
    // Return the scrubbed data
    return actorData;
}
/* -------------------------------------------- */
/**
 * Migrate a single Item entity to incorporate latest data model changes
 * @param item
 */
export const migrateItemData = function (item) {
    const updateData = {};
    // Remove deprecated fields
    _migrateRemoveDeprecated(item, updateData);
    // Return the migrated update data
    return updateData;
};
/* -------------------------------------------- */
/**
 * Migrate a single Scene entity to incorporate changes to the data model of it's actor data overrides
 * Return an Object of updateData to be applied
 * @param {Object} scene  The Scene data to Update
 * @return {Object}       The updateData to apply
 */
export const migrateSceneData = function (scene) {
    const tokens = duplicate(scene.tokens);
    return {
        tokens: tokens.map(t => {
            if (!t.actorId || t.actorLink || !t.actorData.data) {
                t.actorData = {};
                return t;
            }
            const token = new Token(t);
            if (!token.actor) {
                t.actorId = null;
                t.actorData = {};
            }
            else if (!t.actorLink) {
                const updateData = migrateActorData(token.data.actorData);
                t.actorData = mergeObject(token.data.actorData, updateData);
            }
            return t;
        })
    };
};
/* -------------------------------------------- */
/**
 * A general migration to remove all fields from the data model which are flagged with a _deprecated tag
 * @private
 */
const _migrateRemoveDeprecated = function (ent, updateData) {
    const flat = flattenObject(ent.data);
    // Identify objects to deprecate
    const toDeprecate = Object.entries(flat).filter(e => e[0].endsWith("_deprecated") && (e[1] === true)).map(e => {
        let parent = e[0].split(".");
        parent.pop();
        return parent.join(".");
    });
    // Remove them
    for (let k of toDeprecate) {
        let parts = k.split(".");
        parts[parts.length - 1] = "-=" + parts[parts.length - 1];
        updateData[`data.${parts.join(".")}`] = null;
    }
};
